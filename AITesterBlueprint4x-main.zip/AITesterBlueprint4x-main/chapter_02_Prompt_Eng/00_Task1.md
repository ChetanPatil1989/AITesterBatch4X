#### Task :  Write a Selenium Code for the Sales Force login  [login.salesforce.com/?locale=in](https://login.salesforce.com/?locale=in) 
