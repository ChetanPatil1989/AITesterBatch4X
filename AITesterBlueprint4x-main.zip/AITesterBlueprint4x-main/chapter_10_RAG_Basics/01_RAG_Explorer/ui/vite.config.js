import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5190,
    open: true,
    proxy: { '/api': { target: 'http://localhost:8100', changeOrigin: true } },
  },
});
